from turtle import Turtle

class Score(Turtle):

    def __init__(self):
        super().__init__()
        self.penup()
        self.goto(0, 600 / 2 - 40)
        self.hideturtle()
        self.score = 0
        self.high_score = 0

    def score_display(self):
        self.clear()
        self.write(f"Score: {self.score}    High Score: {self.high_score}", align="center", font=("Arial", 20, "bold"))

    def reset(self):
        if self.score > self.high_score:
            self.high_score = self.score
        self.score = 0
    def display_game_over(self):
        self.write("Game Over.", align="center", font=("Courier", 24, "normal"))
