from turtle import Screen
import time

# custom files
from snake import Snake
from food import Food
from score import Score

# Screen Setup
screen = Screen()
screen.setup(width=600, height=600)
screen.bgcolor("PeachPuff1")
screen.title("Python")
screen.tracer(0)


# Game variables
game_is_on = True
score_text = Score()

with open("highscore.txt", "r") as file:
    high_score = file.read().strip()  # strip() removes any leading/trailing whitespace
    high_score = int(high_score) if high_score else 0  # Set to 0 if the file is empt
    score_text.score_display()

gameover_text = Score()
snake = Snake()
food = Food()

# Keyboard input
screen.listen()
screen.onkey(snake.up, "Up")
screen.onkey(snake.down, "Down")
screen.onkey(snake.left, "Left")
screen.onkey(snake.right, "Right")


# Score board
score_text.high_score = high_score
score_text.score_display()


while game_is_on:
    screen.update()
    time.sleep(0.06)
    snake.move()


    # collision with body
    for segment in snake.segments[2:]:
        if snake.head.distance(segment) < 15:
            game_is_on = False
            break
    # collision with wall
    if snake.head.xcor() > 290 or snake.head.xcor() < -290 or snake.head.ycor() > 290 or snake.head.ycor() < -290:
        game_is_on = False
        break

    # detect collision with food
    if snake.head.distance(food) < 20:
        food.random_position()
        snake.create_segment(len(snake.segments))
        score_text.score += 1
        score_text.score_display()

    if score_text.score > score_text.high_score:
        score_text.high_score += 1
        score_text.score_display()

# save highscore
if score_text.score > high_score:
    with open("highscore.txt", "w") as file:  # Open the file in write mode
        file.write(str(score_text.score))  # Write the new high score as a string
        score_text.score_display()
# Game ends
gameover_text.penup()
gameover_text.goto(0,0)
gameover_text.display_game_over()
screen.exitonclick()

