import random
from turtle import Turtle

X_BOUNDS = 250
Y_BOUNDS = 250

is_spawned = False


class Food(Turtle):

    # render a small circle
    # each time snake touches food moves to a new random location
    def __init__(self):
        super().__init__()
        self.penup()
        self.speed("fastest")
        self.shape("square")
        self.shapesize(stretch_len=0.6, stretch_wid=0.6)
        self.color("brown3")
        self.random_position()

    def random_position(self):
        global is_spawned
        is_spawned = True
        random_x_position = random.randint(-X_BOUNDS, X_BOUNDS)
        random_y_position = random.randint(-Y_BOUNDS, Y_BOUNDS)
        self.goto(random_x_position, random_y_position)
        print(random_x_position, " ", random_y_position)

